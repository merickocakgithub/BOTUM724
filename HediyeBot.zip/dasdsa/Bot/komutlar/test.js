const Discord = require("discord.js");
const client  = new Discord.Client();

client.on("ready", () => {
  console.log("Artık Aktifim Bro");
});

client.on("message", (message) => {
  if (message.content.startsWith("Off")) {
    message.channel.send("Yine Senin Canını Kim Sıktı Bro!");
  }
});
client.login(ayarlar.token);