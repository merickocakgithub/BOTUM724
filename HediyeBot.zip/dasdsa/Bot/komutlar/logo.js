const Discord = require('discord.js');
const client = new Discord.Client();

exports.run = (client, message) => {
 message.channel.send({embed: {
		  file:"https://ephmedia.giphy.com/cbed683f-8e16-48f9-a585-75e1924ab9a8.gif",
          color: 0xD97634,
		  description: "**:T�rk Yapm Olan Scary'e �zel Logomuz!**"
            }});
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['p'],
  permLevel: 0
};

exports.help = {
  name: 'logo',
  description: 'Scary Logo.',
  usage: 'logo'
};
