const Discord = require('discord.js');
const client = new Discord.Client();

exports.run = (client, message) => {
 message.channel.send({embed: {
		  file:"https://giphy.com/gifs/dance-twerk-cCWeA4TcQCrhC",
          color: 0xD97634,
		  description: "**Twerk Bebe?im!**"
            }});
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ['p'],
  permLevel: 0
};

exports.help = {
  name: 'twerk',
  description: 'Twerk Yapan Ki?i G�sterir',
  usage: 'twerk'
};
